157.245.234.102

Dynamic elements found on home/landing page

//ASSIGNMENT 5
Page Metrics Found on dashboard tab
login and register pages only appear when no user is logged in and therefore have no unique visits
Users cannot access registration or login page URL while signed in
Users cannot access dashboard URL when no user logged in